Entity = Class.extend({
    init: function() {
    },

    update: function() {
    }
});